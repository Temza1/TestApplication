package com.example.testapplication.domain

data class AuthPhone(
    val isSuccess: Boolean
)